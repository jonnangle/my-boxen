# autoenv Puppet Module for Boxen

Installs autoenv.

[![Build Status](https://travis-ci.org/boxen/puppet-autoenv.png?branch=master)](https://travis-ci.org/boxen/puppet-autoenv)

## Usage

```puppet
include autoenv
```

## Required Puppet Modules

* `boxen`
