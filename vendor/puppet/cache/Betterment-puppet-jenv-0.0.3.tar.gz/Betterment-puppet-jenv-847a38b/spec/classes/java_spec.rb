require 'spec_helper'

describe 'java' do
  it do
    should contain_anchor('Hello_World')
  end
end
